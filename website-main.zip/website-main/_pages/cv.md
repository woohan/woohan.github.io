---
layout: archive
title: "Education"
permalink: /cv/
author_profile: true
redirect_from:
  - /resume
---

{% include base_path %}

* 2013 - 2017, B.S.,  Computer Science, **Beijing University of Posts and Telecommunications**
* 2017 - 2023, Ph.D, Computer Science, **Beihang University**

Work Experience
======
* Feb 2023, PDRA in the **University of Birmingham**
