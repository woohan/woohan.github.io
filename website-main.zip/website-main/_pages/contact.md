---
layout: archive
title: "Contact"
permalink: /contact/
author_profile: true
---

Dr Yihua Cheng (程义华)

Intelligent Robotics Lab.  
Room 106  
School of Computer Science  
University of Birmingham  
Birmingham, B15 2TT  
United Kingdom  

**E-mail:** y.cheng.2@bham.ac.uk

